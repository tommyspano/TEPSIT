package es_Teatro;

import java.util.Scanner;

public class MAIN {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int righe = 15;
        int colonne = 46;
        boolean[][] posti = new boolean[righe][colonne]; // Matrice per i posti

        // Creazione dei thread (spettatori)
        Thread[] spettatori = new Thread[7];
        for (int i = 0; i < spettatori.length; i++) {
            spettatori[i] = new Thread(new MyRunnable(posti, "Spettatore " + (i + 1)));
            spettatori[i].start(); // Avvia il thread
        }

        // Attesa di 10 secondi prima di mostrare i posti disponibili
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Calcolo e stampa dei posti disponibili
        int postiDisponibili = 0;
        for (boolean[] fila : posti) {
            for (boolean posto : fila) {
                if (!posto) {
                    postiDisponibili++;
                }
            }
        }
        System.out.println("Posti disponibili nel cinema: " + postiDisponibili);

        // Aspetto che tutti i thread terminino
        for (Thread spettatore : spettatori) {
            try {
                spettatore.join();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        System.out.println("Simulazione completata.");
    }
    scanner.close();
}
