package es_Teatro;

import java.util.Random;

public class MyRunnable implements Runnable{
	private final boolean[][] posti; // Matrice per i posti
    private final String nome;
    private final Random random = new Random();

    public MyRunnable(boolean[][] posti, String nome) {
        this.posti = posti;
        this.nome = nome;
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) { // Ogni spettatore tenta di prenotare 5 posti
            // Calcola i posti centrali da prenotare
            int fila = random.nextInt(15); // Sceglie una fila casuale
            int posto = 22 + random.nextInt(3); // Sceglie un posto centrale (21, 22 o 23)

            // Tentativo di prenotazione
            prenotaPosto(fila, posto);

            // Attesa tra le prenotazioni
            try {
                Thread.sleep(100); // Attende 100 ms tra una prenotazione e l'altra
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private synchronized void prenotaPosto(int fila, int posto) {
        if (!posti[fila][posto]) { // Se il posto è libero
            posti[fila][posto] = true; // Prenota il posto
            System.out.println(nome + " ha prenotato il posto: Fila " + fila + ", Posto " + posto);
        } else {
            System.out.println(nome + " ha tentato di prenotare il posto: Fila " + fila + ", Posto " + posto + " ma è già occupato.");
        }
    }
}
