package es_thread2;

public class MyRunnable implements Runnable{
	
	private int contatore = 1;  // Numero condiviso tra i thread
    private int numMax;
    
    public MyRunnable(int numMax) {
       this.numMax = numMax;  // Imposta il numero massimo
    }

    private synchronized void printNum() {
        while (contatore <= numMax) {
            System.out.println(Thread.currentThread().getName() + " ha stampato: " + contatore);
            contatore++;  // Incrementa il numero condiviso
            try {
                // Attende un breve tempo per simulare la collaborazione tra thread
                Thread.sleep(100);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();  // Ripristina lo stato di interruzione
            }
        }
    }
    
    public void run() {
        printNum();  // Ogni thread invoca il metodo synchronized
    }
}
