package es_thread2;

import java.util.Scanner;

public class MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Inserisci il numero di thread t: ");
		int t = scanner.nextInt();
		
		System.out.print("Inserisci il numero massimo da contare n: ");
        int n = scanner.nextInt();
        
        
     // Creazione e avvio dei thread
        Thread[] threads = new Thread[t];
        MyRunnable myRunnable = new MyRunnable(n);  // Un'unica istanza di MyRunnable condivisa tra i thread

        for (int i = 0; i < t; i++) {
            threads[i] = new Thread(myRunnable, "Thread:" + (i + 1));
            threads[i].start();
        }

        // Attesa della terminazione di tutti i thread
        
        scanner.close();
    }


}
