package es_thread2;

import java.util.Scanner;

public class MAIN {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Chiede all'utente il numero di thread (T) e il valore massimo (N)
        System.out.print("Inserisci il numero di thread (T): ");
        int t = input.nextInt();

        System.out.print("Inserisci il numero massimo (N): ");
        int nmax = input.nextInt();

        // Crea i thread e li avvia
        Thread[] threads = new Thread[t];
        MyRunnable[] myRunnables = new MyRunnable[t];

        // Inizializza i Runnable e crea i Thread
        for (int i = 0; i < t; i++) {
            myRunnables[i] = new MyRunnable(nmax);
            threads[i] = new Thread(myRunnables[i], "Thread-" + (i + 1));
            threads[i].start();
        }

        // Ciclo che stampa lo stato dei thread periodicamente
        while (true) {
            boolean allCompleted = true;

            // Verifica lo stato di ciascun thread
            for (int i = 0; i < t; i++) {
                if (threads[i].isAlive()) {
                    System.out.println(threads[i].getName() + " è attivo. Valore corrente: " + myRunnables[i].getCurrent());
                    allCompleted = false;  // Se uno dei thread è ancora attivo, non tutti sono completati
                } else {
                    System.out.println(threads[i].getName() + " COMPLETATO.");
                }
            }

            // Se tutti i thread sono terminati, esci dal ciclo e stampa il messaggio di completamento
            if (allCompleted) {
                System.out.println("TUTTI I THREAD COMPLETATI.");
                break;
            }

            // Pausa di un secondo prima di verificare nuovamente lo stato
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        // Chiude lo scanner
        input.close();
    }
}
