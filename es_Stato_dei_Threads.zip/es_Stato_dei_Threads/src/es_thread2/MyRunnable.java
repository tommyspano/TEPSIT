package es_thread2;

import java.util.Random;

public class MyRunnable implements Runnable {
    private final int maxNumber;
    private int current;  // Valore corrente fino a cui il thread ha contato

    // Costruttore che accetta il valore massimo N e inizializza il valore corrente
    public MyRunnable(int maxNumber) {
        this.maxNumber = new Random().nextInt(maxNumber + 1);  // Genera un numero casuale tra 0 e N
        this.current = 0;  // Il thread inizia a contare da 0
    }

    // Metodo che restituisce il valore corrente
    public int getCurrent() {
        return current;
    }

    @Override
    public void run() {
        while (current < maxNumber) {
            current++;  // Incrementa il valore corrente
            try {
                Thread.sleep(120);  // Pausa di 120ms tra ogni incremento
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();  // Ripristina lo stato di interruzione
            }
        }
    }
}