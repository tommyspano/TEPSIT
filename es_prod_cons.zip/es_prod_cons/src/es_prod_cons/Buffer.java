package es_prod_cons;

public class Buffer {
	private int[] queue;
	private int head; //indice di testa
	private int tail; //indice di inserimento successivo
	private int capacity; //dimensione massima della coda
	private int size; //numnero attuale di elementi presenti nella coda
	
	public Buffer(int capacity) {
		this.capacity = capacity;
		queue = new int [capacity];
		head = 0;
		tail = 0;
		size = 0;
	}
	
	//metodo sincronizzato per inserire nella coda
	public synchronized void enqueue(int value) throws InterruptedException{
		while (size == capacity) wait();  //se la coda è piena, il thread aspetta
		queue[tail] = value; //inserisco il valore
		tail = (tail + 1) % capacity; //movimento circolare della coda
		size++; //una volta inserito il valore, incremento size
		notifyAll(); //qualora ci fossero dei consumatori in attesa, notifyAll() li mette tutti nello stato di pronto
	}
	
	//metodo sincronizzato per svuotare la coda
	public synchronized int dequeue() throws InterruptedException{
		while(size == 0) wait(); //se la coda è vuota, il thread aspetta
		int value = queue[head];
		head = (head + 1) % capacity; //movimento circolare della coda
		size--; //essendo che vado a levare l'elemento dalla cosa, poi decrementerò di uno il count size
		notifyAll();  //qualora ci fossero dei produttori in attesa, notifyAll() li mette tutti nello stato di pronto
		return value;
	}
}

