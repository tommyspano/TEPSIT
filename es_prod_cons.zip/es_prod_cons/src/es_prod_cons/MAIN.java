package es_prod_cons;

import java.util.Random;
import java.util.Scanner;

public class MAIN {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Inserisci il numero di thread T: ");
		int T = scanner.nextInt();
		
		System.out.println("Inserisci il valore massimo N: ");
		int N = scanner.nextInt();
		
		Buffer buffer = new Buffer(10); //creiamo un buffer con una capacità fissa
		
		
		// Creazione e avvio dei thread Produttori
        for (int i = 0; i < T; i++) {
            new Thread(new Produttore(buffer)).start();
        }

        // Creazione e avvio del thread Consumatore
        new Thread(new Consumatore(buffer)).start();

        // Thread contatori
        for (int i = 0; i < T; i++) {
            new Thread(() -> {
                try {
                    Random random = new Random();
                    int x = random.nextInt(N + 1); // Conta fino a un numero casuale tra 0 e N
                    for (int j = 0; j <= x; j++) {
                        Thread.sleep(120); // Attesa di 120ms per ogni incremento
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }).start();
            scanner.close();
        }
    }
}
