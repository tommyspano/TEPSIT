package es_prod_cons;

public class LIFO {
	private int[] stack;
    private int top;
    private int capacity;

    public LIFO(int capacity) {
        this.capacity = capacity;
        stack = new int[capacity];
        top = -1;
    }

    public synchronized void push(int value) throws InterruptedException {
        while (top == capacity - 1) wait(); // Aspetta se la pila è piena
        stack[++top] = value;
        notifyAll(); // Notifica eventuali consumatori
    }

    public synchronized int pop() throws InterruptedException {
        while (top == -1) wait(); // Aspetta se la pila è vuota
        int value = stack[top--];
        notifyAll(); // Notifica eventuali produttori
        return value;
    }
}
