package es_prod_cons;

public class Consumatore implements Runnable{

	private Buffer buffer;
	private int pari;
	private int dispari;
	
	public Consumatore(Buffer buffer) {
		this.buffer = buffer;
		pari = 0;
		dispari = 0;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				int number = buffer.dequeue();
				if (number % 2 == 0) pari++;
				else dispari++;
				System.out.println("Numero consumato: " + number);
				System.out.println("Numeri pari: " + pari + " | Numeri dispari: " + dispari);
				
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}
	}
	
}
