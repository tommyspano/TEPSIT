package es_prod_cons;

import java.util.Random;

public class Produttore implements Runnable{

	private Buffer buffer;
	private Random random = new Random();
	
	public Produttore(Buffer buffer) {
		this.buffer = buffer;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
			try {
				int number = random.nextInt(1024); //genera un numero tra 0 e 1023
				buffer.enqueue(number);
				int sleepTime = 100 + random.nextInt(901); // thread pausa tra 100 e 1000 millisecondi
				Thread.sleep(sleepTime);
			} catch(InterruptedException e) {
				e.printStackTrace();
			}
			
		}
	}
	
}
